//
//  CustomCell.swift
//  UICollectionView
//
//  Created by Oshima Yoshiki on 12/6/15.
//  Copyright © 2015 Oshima Yoshiki. All rights reserved.
//

import UIKit

class CustomCell: UICollectionViewCell {
    @IBOutlet weak var image: UIImageView!
    
    override func awakeFromNib() {
        self.image.contentMode = UIViewContentMode.ScaleAspectFill
    }
}
