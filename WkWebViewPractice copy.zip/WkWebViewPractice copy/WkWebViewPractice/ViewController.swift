//
//  ViewController.swift
//  WkWebViewPractice
//
//  Created by Oshima Yoshiki on 12/4/15.
//  Copyright (c) 2015 Oshima Yoshiki. All rights reserved.
//

import UIKit
import WebKit

class ViewController: UIViewController, WKNavigationDelegate {

    @IBOutlet weak var titleLabel: UILabel!
    let myWkWebView = WKWebView()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        myWkWebView.frame = CGRectMake(0, 64, self.view.frame.width, self.view.frame.height-(64 + 44))
        self.view.addSubview(myWkWebView)
        myWkWebView.addObserver(self, forKeyPath: "title", options: .New, context: nil)
        myWkWebView.navigationDelegate = self
        let myURL = NSURL(string:"http://wired.jp/")
        let myURLRequest = NSURLRequest(URL: myURL!)
        myWkWebView.loadRequest(myURLRequest)
    }
    
    
    override func observeValueForKeyPath(keyPath: String?, ofObject object: AnyObject?, change: [String : AnyObject]?, context: UnsafeMutablePointer<Void>) {
        titleLabel.text = myWkWebView.title
    }

    deinit {
        myWkWebView.removeObserver(self, forKeyPath: "title")
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

    
    @IBAction func backBtn(sender: UIButton) {
        myWkWebView.goBack()
    }
    
    
    @IBAction func forwardBtn(sender: UIButton) {
        myWkWebView.goForward()
    }
    
    @IBAction func reloadBtn(sender: UIButton) {
        myWkWebView.reload()
    }
    

    @IBAction func stopBtn(sender: UIButton) {
        myWkWebView.stopLoading()
    }
    
    
    func webView(webView: WKWebView, didStartProvisionalNavigation navigation: WKNavigation!) {
        UIApplication.sharedApplication().networkActivityIndicatorVisible = true
    }
    
    func webView(webView: WKWebView, didFinishNavigation navigation: WKNavigation!) {
        UIApplication.sharedApplication().networkActivityIndicatorVisible = false
    }
    
}

